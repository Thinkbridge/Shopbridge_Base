using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ShopBridge.Businness;
using ShopBridge.DTO;

namespace ShopBridge.API
{
    [ApiController]
    [Route("product")]
    [Authorize]
    public class ProductController : ControllerBase
    {
        private readonly ProductService _service;
        private readonly ILogger<ProductController> _logger;

        public ProductController(ProductService productService, ILogger<ProductController> logger)
        {
            _service = productService;
            _logger = logger;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Product>> GetProduct(int id)
        {
            var product = await _service.GetProduct(id);
            return product;
        }

        [HttpGet]
        [Route("GetAllProducts")]
        public async Task<ActionResult<List<Product>>> GetProducts(int page = 1, int pageSize = 10, string? searchTerm = null)
        {
            var products = await _service.GetAllProducts(page, pageSize, string.IsNullOrEmpty(searchTerm) ? string.Empty : searchTerm);
            return new JsonResult(products);
        }

        [HttpPost]
        public async Task<ActionResult<Product>> AddProduct(Product product)
        {
            if (product == null)
                throw new ProductException($"Product is InValid.");

            var addedProduct = await _service.AddProduct(product);

            return CreatedAtAction(nameof(GetProduct), new { id = product.Id }, product);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<Product>> UpdateProduct(int id, Product product)
        {
            if (id != product.Id)
                throw new ProductException($"Product ids doesn't match.");

            var updatedProduct = await _service.UpdateProduct(id, product);
            return updatedProduct;
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<Product>> DeleteProduct(int id)
        {
            await _service.DeleteProduct(id);
            return new JsonResult("SuccessFully Deleted");
        }
    }
}